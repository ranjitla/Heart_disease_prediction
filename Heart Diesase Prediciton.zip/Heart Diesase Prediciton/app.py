from flask import Flask, render_template, request
import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
import joblib  # Ensure joblib is imported for model loading
import os

# Initialize Flask app
app = Flask(__name__)

# Path to the pre-trained model
model_path = r"C:\Users\kumar\OneDrive\Desktop\Heart Diesase Prediciton\heartdiseasemodel.pkl"

# Check if the model file exists
if os.path.exists(model_path):
    try:
        model = joblib.load(model_path)
        print("Model loaded successfully.")
    except Exception as e:
        print(f"Error loading model: {e}")
        model = None
else:
    print("Model file not found. Training a new model instead.")
    model = None

# Load and prepare the dataset
try:
    df = pd.read_csv("heart.csv")
    X = df[['age', 'cp', 'thalach']]
    Y = df['target']
    print("Dataset loaded successfully.")
except FileNotFoundError:
    print("Error: Dataset not found. Please ensure 'heart.csv' is in the project directory.")
    exit()

# Train a new logistic regression model if the pre-trained model isn't loaded
if model is None:
    try:
        model = LogisticRegression(max_iter=1000)  # Ensure convergence
        X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size=0.2, random_state=1)
        model.fit(X_train, Y_train)
        print("Model trained successfully.")
        # Optionally save the model for future use
        joblib.dump(model, model_path)
        print(f"New model saved at: {model_path}")
    except Exception as e:
        print(f"Error during model training: {e}")
        exit()

@app.route("/", methods=["GET", "POST"])
def index():
    result = None
    error_message = None

    if request.method == "POST":
        try:
            # Get input from the user
            age = request.form.get("age")
            cp = request.form.get("cp")
            thalach = request.form.get("thalach")

            # Validate user input
            if not (age and cp and thalach):
                raise ValueError("All fields are required.")

            age = int(age)
            cp = int(cp)
            thalach = int(thalach)

            if age <= 0 or cp < 0 or thalach <= 0:
                raise ValueError("Inputs must be positive integers.")

            # Make prediction
            user_data = np.array([[age, cp, thalach]])
            prediction = model.predict(user_data)[0]
            result = "Heart Disease" if prediction == 1 else "No Heart Disease"

        except ValueError as ve:
            error_message = f"Input error: {ve}"
        except Exception as e:
            error_message = f"An unexpected error occurred: {e}"

    return render_template("index.html", result=result, error=error_message)

if __name__ == "__main__":
    app.run(debug=True)
